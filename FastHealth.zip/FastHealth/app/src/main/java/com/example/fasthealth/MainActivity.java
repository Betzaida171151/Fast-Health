package com.example.fasthealth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //Método del botón Registrate
    public void registate (View view){
        Intent registrate = new Intent(this, Registro.class);
        startActivity(registrate);
    }
}