package com.example.fasthealth;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.fasthealth.ui.login.Login;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView bottomnav=findViewById(R.id.bottom_navigation);
        bottomnav.setOnNavigationItemSelectedListener(navListener);
        Intent intent = new Intent(MainActivity.this, Login.class);
        startActivity(intent);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectedfragment=null;

            switch(item.getItemId()){
                case R.id.ini:
                    selectedfragment = new FragmentoInicio();
                    break;
                case R.id.calc:
                    selectedfragment = new FragmentoIMC();
                    break;
                case R.id.logs:
                    selectedfragment = new FragmentoLogros();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,selectedfragment).commit();
            return true;
        }
    };
}